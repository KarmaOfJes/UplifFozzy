import urllib
import sqlalchemy
import pyodbc
from tqdm.auto import trange, tqdm
import gc
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from scipy import spatial
from sklearn.decomposition import PCA
from sklearn.neural_network import MLPClassifier
from sklearn import preprocessing
from datetime import datetime
from dateutil.relativedelta import *
from typing import Iterable, List, Tuple, Union, Optional, Generator

import pickle as pk

def connect_to_DB():
    
    server_name = 'S-KV-CENTER-S60,56234'
    _db_conn = ('DRIVER={ODBC Driver 17 for SQL Server};'
            f'Server={server_name};'
            'Trusted_Connection=yes;')
    db_conn = pyodbc.connect(_db_conn)
    _db_args = urllib.parse.quote_plus(_db_conn)
            
    engine = sqlalchemy.create_engine(f'mssql+pyodbc:///?odbc_connect={_db_args}')
    engine.connect()
    
    cnxn = pyodbc.connect(_db_conn)
    cnxn.autocommit = True
    cursor = cnxn.cursor()
    
    return cursor, engine


def read_sql(query, chunk_size = 5_000_000, verbose=False, n_rows=None):
    
    server_name = 'S-KV-CENTER-S60,56234'
    _db_conn = ('DRIVER={ODBC Driver 17 for SQL Server};'
                f'Server={server_name};'
                'Trusted_Connection=yes;')
    db_conn = pyodbc.connect(_db_conn)


    _db_args = urllib.parse.quote_plus(_db_conn)
    engine = sqlalchemy.create_engine(f'mssql+pyodbc:///?odbc_connect={_db_args}')
    engine.connect()


    # result rows count must be passed explicitly
    if verbose:
        if n_rows is None:
            raise ValueError('Must pass `n_rows` with verbose set `True`!')
        n_chunks = int(np.ceil(n_rows/chunk_size))
    cursor = db_conn.execute(query)
    cols = [column[0].lower() for column in cursor.description]
    _df = []
    if verbose:
        for chunk in trange(n_chunks):
            _df.append(pd.DataFrame((tuple(row)
                                     for row in cursor.fetchmany(chunk_size)), columns=cols))
            gc.collect()
    else:
        while True:
            data = cursor.fetchmany(chunk_size)
            if not data:
                break
            _df.append(pd.DataFrame((tuple(row)
                                     for row in data), columns=cols))
            gc.collect()
    return pd.concat(_df)

def prep_stratification_column(df, cont_vars2stratify: Iterable[str] = None,
                               descr_vars2stratify: Iterable[str] = None, 
                               verbose=False, bins_per_con_var=10) -> pd.Series:
    stratification = pd.DataFrame()
    # create descre bins from continuable var
    if cont_vars2stratify is not None:
        for var in cont_vars2stratify:
            stratification[var] = pd.qcut(
                df[var], np.linspace(0, 1, bins_per_con_var)).cat.codes
            if verbose:
                # breakpoint()
                members_per_bin = stratification[var].value_counts()
                print(f"Var: {var}, members per bin: {members_per_bin}")
    if descr_vars2stratify is not None:
        for var in descr_vars2stratify:
            stratification[var] = df[var].copy()
            if verbose:
                # breakpoint()
                members_per_bin = stratification[var].value_counts()
                print(f"Var: {var}, members per bin: {members_per_bin}")
    if not stratification.size:
        stratification = None
    else:
        # TODO: replace with encoding
        stratification = stratification.astype(str).sum(1)
    return stratification

def split_cgpg(df, test_size,
               cont_vars2stratify: Iterable[str] = None,
               descr_vars2stratify: Iterable[str] = None,
               verbose=False, random_state=42, bins_per_con_var = 10):
    """
    Splits df index into CG & PG stratified by continuous variable

    Returns: cg, pg
    """
    from sklearn.model_selection import train_test_split

    stratification = prep_stratification_column(
        df, cont_vars2stratify, descr_vars2stratify, bins_per_con_var = bins_per_con_var, verbose = verbose)
    cg, pg = train_test_split(df.index, test_size=test_size,
                              stratify=stratification, random_state=random_state)
    return cg, pg