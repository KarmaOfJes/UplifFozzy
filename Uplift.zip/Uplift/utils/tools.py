import yaml
from typing import Iterable
import pandas as pd
import numpy as np
from dateutil.relativedelta import relativedelta


def load_yaml(path):
    with open(path, encoding='utf8') as file:
        result = yaml.safe_load(file)
    return result


def prep_stratification_column(df, cont_vars2stratify: Iterable[str] = None,
                               descr_vars2stratify: Iterable[str] = None,
                               verbose=False, bins_per_con_var=10) -> pd.Series:
    stratification = pd.DataFrame()
    # create descre bins from continuable var
    if cont_vars2stratify is not None:
        for var in cont_vars2stratify:
            stratification[var] = pd.qcut(
                df[var], np.linspace(0, 1, bins_per_con_var)).cat.codes
            if verbose:
                # breakpoint()
                members_per_bin = stratification[var].value_counts()[0]
                print(f"Var: {var}, members per bin: {members_per_bin}")
    if descr_vars2stratify is not None:
        for var in descr_vars2stratify:
            stratification[var] = df[var].copy()
    if not stratification.size:
        stratification = None
    else:
        # TODO: replace with encoding
        stratification = stratification.astype(str).sum(1)
    return stratification


def split_cgpg(df, test_size,
               cont_vars2stratify: Iterable[str] = None,
               descr_vars2stratify: Iterable[str] = None,
               random_state=42, bins_per_con_var=10):
    """
    Splits df index into CG & PG stratified by continuous variable

    Returns: cg, pg
    """
    from sklearn.model_selection import train_test_split

    stratification = prep_stratification_column(
        df, cont_vars2stratify, descr_vars2stratify, bins_per_con_var=bins_per_con_var)
    cg, pg = train_test_split(df.index, test_size=test_size,
                              stratify=stratification, random_state=random_state)
    return cg, pg


def get_start_thursday_before_n_weeks(start_date: pd.Timestamp, n_weeks: int) -> pd.Timestamp:
    """
    Helper function to inspect the Thursday date before n_weeks from start_date
    """
    if start_date.weekday() >= 4:
        date_before = start_date + relativedelta(weeks=-n_weeks)
    else:
        date_before = start_date + relativedelta(weeks=-(n_weeks + 1))
    return date_before + relativedelta(days=-4 - date_before.weekday(), weeks=1)
