import pandas as pd
import numpy as np
import pyodbc
import sqlalchemy
import urllib
from sqlalchemy import create_engine

con = {'host': 'SFPA-SQLS100', 'port': '56234', 'db': 'Marketing',
       'driver': 'ODBC+Driver+17+for+SQL+Server',
       'dialect': 'mssql+pyodbc',
       'auth': 'trusted_connection=yes'}
con_str = "{dialect}://@{host}:{port}/{db}?{auth}&driver={driver}".format(**con)
conn = create_engine(con_str)

db_schema = 'Marketing.cvm'


def connect_phone_number(
        audience_id: str,
        table_name: str
) -> pd.DataFrame:
    """
    Load phone numbers for members in pilot groups (is_pg=1) who do not use mobile app
    but that are reachable via Viber or SMS (their phone number is known)
    
    :param audience_id: id of the campaign 
    :param table_name: name of the DB table which contains all parameters for the campaign and its members
    :param db_schema: path to table_name 
    
    :return: dataframe with all members assigned for specified campaign with mobile phone numbers (if exist)
    """
    q_mob_ph = f'''
    select memberId, phone_number as mobile_phone
      from Marketing.cvm.cvm_phone_numbers (nolock)
     where memberId in (select memberId 
                          from {db_schema}.{table_name}
                         where audience_id = '{audience_id}' 
                           and is_pg = 1
                           and channel = 'viber')'''
   
    q_mbr = f'''
    select mb.*
      from {db_schema}.{table_name} as mb
     where audience_id = '{audience_id}' '''        
    
    df_ph = pd.read_sql(q_mob_ph, conn)
    df_mbr = pd.read_sql(q_mbr, conn)
    
    df = pd.merge(df_mbr, df_ph, on='memberId', how='left')

    report = df.groupby(['audience_id', 'is_pg', 'group_id', 'channel']).agg({'memberId': 'nunique',
                                                                              'mobile_phone': 'count'}).reset_index()

    report.loc[report.apply(lambda row: row['channel'] not in ['coupon', 'mp'] and row['is_pg'] == True, axis=1),
               'missing_phone'] = report['memberId'] - report['mobile_phone']
    report['missing_phone'].fillna('', inplace=True)
    display(report.drop('mobile_phone', axis=1))
    return df


def load_campaign(audience_id: str,
                  table_name: str,
                  connect_phone: bool = False) -> pd.DataFrame:

    if connect_phone:
        df = connect_phone_number(audience_id, table_name)
    else:
        q = f''' 
            select audience_id,
                   is_pg,
                   group_id,
                   channel,
                   memberId
              from {db_schema}.{table_name} 
             where audience_id = '{audience_id}' 
            '''
        df = pd.read_sql(q, conn)
    return df

def normalizefilename(fn):
    validchars = "-()%"
    out = ""
    pred = ''
    for c in fn:
        if str.isalpha(c) or str.isdigit(c) or (c in validchars):
            out += c
            pred = c
        else:
            if pred == '_':
                out += ''
            else:
                out += "_"
            pred = "_"
        
    return out  

class PreparePilotGroups(): 
    
    def __init__(self, audience_id: str, table_name: str, connect_phone: bool = True):
        self.audience_id = audience_id
        self.table_name = table_name
        self.df = load_campaign(audience_id, table_name, connect_phone)

    def handle_missing_phone(self, to_do: str):

        mbr_no_phone = lambda row: row['channel'] not in ['coupon', 'mp'] and row['is_pg'] == True and pd.isna(row['mobile_phone'])

        if to_do == 'assign_coupon':
            if 'coupon' in self.df['channel'].unique():
                self.df.loc[self.df.apply(mbr_no_phone, axis=1), 'channel'] = 'coupon'
            else:
                raise Exception('No group with "coupon" channel found')
        elif to_do == 'delete':
            self.df.drop(self.df[self.df.apply(mbr_no_phone, axis=1)].index, inplace=True)
        else:
            raise Exception('Not defined action')
    
    def check(self):
        display(self.df.groupby(['audience_id', 'is_pg', 'group_id'])[['memberId']].nunique())
        display(self.df.groupby(['audience_id', 'is_pg', 'group_id', 'channel'])[['memberId']].nunique())
        
    def save(self, folder: str, groups_mapping: dict = None,promo_mapping: dict = None):
        pg = self.df[self.df['is_pg'] == 1].copy()
        pg['offer'] = pg['group_id'].map(groups_mapping)
        pg['promoid'] = pg['group_id'].map(promo_mapping)
        channels = pg['channel'].unique()

        for gr in groups_mapping.keys():
            for ch in channels:
                data = pg[(pg['group_id'] == gr) & (pg['channel'] == ch)].copy()
                if not data.empty:
                    if ch == 'mp':
                        if ('mp' in channels) and ('viber' in channels):
                            emp_df = pd.DataFrame([[str(self.audience_id), gr, 1, 'mp', 33685519, '', 1.0],
                                                   [str(self.audience_id), gr, 1, 'mp', 39851194, '', 1.0],
                                                   [str(self.audience_id), gr, 1, 'mp', 18920661, '', 1.0],
                                                   [str(self.audience_id), gr, 1, 'mp', 13728653, '', 1.0],
                                                   [str(self.audience_id), gr, 1, 'mp', 11972114, '', 1.0],
                                                   [str(self.audience_id), gr, 1, 'mp', 39121000, '', 1.0]],
                                                  columns=['audience_id', 'group_id', 'is_pg', 'channel',
                                                           'memberId', 'mobile_phone', 'rownumber'])
                            emp_df['offer'] = emp_df['group_id'].map(groups_mapping)
                            data = data.append(emp_df, ignore_index=True)
                        else:
                            emp_df = pd.DataFrame([[str(self.audience_id), gr, 1, 'mp', 38512001, '', 1.0],
                                                   [str(self.audience_id), gr, 1, 'mp', 37918176, '', 1.0],
                                                   [str(self.audience_id), gr, 1, 'mp', 33685519, '', 1.0],
                                                   [str(self.audience_id), gr, 1, 'mp', 39851194, '', 1.0],
                                                   [str(self.audience_id), gr, 1, 'mp', 18920661, '', 1.0],
                                                   [str(self.audience_id), gr, 1, 'mp', 13728653, '', 1.0],
                                                   [str(self.audience_id), gr, 1, 'mp', 11972114, '', 1.0],
                                                   [str(self.audience_id), gr, 1, 'mp', 39121000, '', 1.0]],
                                                  columns=['audience_id', 'group_id', 'is_pg', 'channel',
                                                           'memberId', 'mobile_phone', 'rownumber'])
                            emp_df['offer'] = emp_df['group_id'].map(groups_mapping)
                            data = data.append(emp_df, ignore_index=True)
                        
                        # Файл для отложенной загрузки купонов в FZC
                        writer = pd.ExcelWriter(f'{folder}/{self.audience_id}_{normalizefilename(groups_mapping[gr])}_MM_{ch}.xlsx',
                                                engine='xlsxwriter')
                        data[['memberId', 'promoid']].to_excel(writer, header=['id_пользователя', 'id_акции'], index=False)
                        workbook = writer.book
                        worksheet = writer.sheets['Sheet1']
                        worksheet.write('B1', 'id_акции')
                        worksheet.write('C1', 'вид_купона')
                        worksheet.write('D1', 'количество_применений')
                        worksheet.write('E1', 'начало_действия_купонов')
                        worksheet.write('F1', 'окончание_действия_купонов')
                        writer.save()
                        
                        # Файл для рассылки
                        writer = pd.ExcelWriter(f'{folder}/{self.audience_id}_{normalizefilename(groups_mapping[gr])}_IR_{ch}.xlsx',
                                                engine='xlsxwriter')
                        data['memberId'].to_excel(writer, header=['memberid'], index=False)
                        workbook = writer.book
                        worksheet = writer.sheets['Sheet1']
                        writer.save()
                        
                    elif ch == 'viber':
                        emp_df = pd.DataFrame([[str(self.audience_id), gr, 1, 'viber', 38512001, '+380999158008', 1.0],
                                               [str(self.audience_id), gr, 1, 'viber', 37918176, '+380634908148', 1.0]],
                                              columns=['audience_id', 'group_id', 'is_pg', 'channel',
                                                       'memberId', 'mobile_phone', 'rownumber'])
                        emp_df['offer'] = emp_df['group_id'].map(groups_mapping)
                        data = data.append(emp_df, ignore_index=True)
                        
                        # Файл для отложенной загрузки купонов в FZC
                        writer = pd.ExcelWriter(f'{folder}/{self.audience_id}_{normalizefilename(groups_mapping[gr])}_MM_{ch}.xlsx',
                                                engine='xlsxwriter')
                        data['memberId'].to_excel(writer, header=['id_пользователя'], index=False)
                        workbook = writer.book
                        worksheet = writer.sheets['Sheet1']
                        worksheet.write('B1', 'id_акции')
                        worksheet.write('C1', 'вид_купона')
                        worksheet.write('D1', 'количество_применений')
                        worksheet.write('E1', 'начало_действия_купонов')
                        worksheet.write('F1', 'окончание_действия_купонов')
                        writer.save()
                        
                        # Файл для рассылки
                        writer = pd.ExcelWriter(f'{folder}/{self.audience_id}_{normalizefilename(groups_mapping[gr])}_IR_{ch}.xlsx',
                                                engine='xlsxwriter')
                        data[['memberId', 'mobile_phone']].to_excel(writer, header=['memberid', 'phonenumber'], index=False)
                        workbook = writer.book
                        worksheet = writer.sheets['Sheet1']
                        writer.save()
                    
                    
    def save_to_sql(self):
        
        server_name = 'SFPA-SQLS100,56234'
        _db_conn = ('DRIVER={ODBC Driver 17 for SQL Server};'
                    f'Server={server_name};'
                    'Trusted_Connection=yes;')
        db_conn = pyodbc.connect(_db_conn)

        _db_args = urllib.parse.quote_plus(_db_conn)
        engine = sqlalchemy.create_engine(f'mssql+pyodbc:///?odbc_connect={_db_args}')
        engine.connect()
        
        
        self.df[['audience_id', 'group_id', 'is_pg', 'channel', 'memberId']].to_sql(
             'frq_campaigns_members_new', engine, schema='Marketing.cvm', index=False, if_exists='append')
