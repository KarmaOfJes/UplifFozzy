import urllib
import sqlalchemy
import pyodbc
from tqdm.auto import trange
import gc
import pandas as pd
import numpy as np


def connect_to_db():
    server_name = 'SFPA-SQLS100,56234'
    _db_conn = ('DRIVER={ODBC Driver 17 for SQL Server};'
                f'Server={server_name};'
                'Trusted_Connection=yes;')
    db_conn = pyodbc.connect(_db_conn)
    _db_args = urllib.parse.quote_plus(_db_conn)

    engine = sqlalchemy.create_engine(f'mssql+pyodbc:///?odbc_connect={_db_args}')
    engine.connect()
    conn = pyodbc.connect(_db_conn)
    conn.autocommit = True
    cursor = conn.cursor()

    return {'cursor': cursor, 'conn': conn, 'engine': engine}


def read_sql(query, chunk_size=5_000_000, verbose=False, n_rows=None):
    server_name = 'SFPA-SQLS100,56234'
    _db_conn = ('DRIVER={ODBC Driver 17 for SQL Server};'
                f'Server={server_name};'
                'Trusted_Connection=yes;')
    db_conn = pyodbc.connect(_db_conn)

    _db_args = urllib.parse.quote_plus(_db_conn)
    engine = sqlalchemy.create_engine(f'mssql+pyodbc:///?odbc_connect={_db_args}')
    engine.connect()

    # result rows count must be passed explicitly
    if verbose:
        if n_rows is None:
            raise ValueError('Must pass `n_rows` with verbose set `True`!')
        n_chunks = int(np.ceil(n_rows / chunk_size))
    cursor = db_conn.execute(query)
    cols = [column[0].lower() for column in cursor.description]
    _df = []
    if verbose:
        for chunk in trange(n_chunks):
            _df.append(pd.DataFrame((tuple(row)
                                     for row in cursor.fetchmany(chunk_size)), columns=cols))
            gc.collect()
    else:
        while True:
            data = cursor.fetchmany(chunk_size)
            if not data:
                break
            _df.append(pd.DataFrame((tuple(row)
                                     for row in data), columns=cols))
            gc.collect()
    return pd.concat(_df)

