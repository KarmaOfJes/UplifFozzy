from IPython.core.display import display
from utils.db_conn import connect_to_db, read_sql
from utils.tools import load_yaml, get_start_thursday_before_n_weeks
import pandas as pd
from data_prep.procedures import ProceduresPipeline, Procedures
from data_prep.local_features import nbo_members, nbo_product, get_productid_price_features, merge_local_features
from data_prep.preprocessing import preprocess_campaign_features, preprocess_historic_columns
from data_prep.trend_features import get_total_ntrn_history, get_m4_ntrn_history, get_slope_by_time
import pickle as pk
from tqdm.auto import tqdm
import time
import sys
import matplotlib.pyplot as plt

db_config = connect_to_db()
cursor = db_config['cursor']
db_conn = db_config['conn']

# TODO: change
final_merge = 'Marketing.cvm.frq_uplift_features_campaign_'


class MultiCmpDesign:

    def __init__(self, cmp_config_path):
        self.cmp_config = load_yaml(cmp_config_path)
        self.start_date = pd.to_datetime(self.cmp_config.get('start_date'))
        self.campaign_name = self.cmp_config.get('campaign_name')
        self.features_config = load_yaml(self.cmp_config.get('features_config'))
        self.label_encoders = pk.load(open(self.cmp_config.get('label_encoders_path'), "rb"))
        self.rewards_info = pd.read_excel(self.cmp_config.get('rewards_info_path'))
        self.table_members = self.cmp_config.get('new_table_members')
        self.members = None
        self.results = None
        self.test()
        self.data = None

    def test(self):

        print('Testing products...')
        le_rn = self.label_encoders['reward_name']
        for row in tqdm(list(self.rewards_info.iterrows())):
            reward_name = row[1]['reward_name']
            if not reward_name in le_rn.classes_:
                print(reward_name, ' is a wrong value for reward_name, chose from available:', le_rn.classes_)

        query = '''select nmp.id as lagerid, lmb.id as product_id, nmp.name4, nmp.name3, nmp.name2, Name
                   from Marketing..new_macro_data_for_program nmp
                   left join Marketing.cvm.ListM4BrandId as lmb
                   on (lmb.m4=nmp.m4 or (lmb.m4 is null and nmp.m4 is null))
                   and (lmb.brandId=nmp.BrandID or (lmb.brandId is null and nmp.BrandID is null))'''
        corr_table = read_sql(query)[['product_id', 'name4', 'name']].drop_duplicates()
        display(self.rewards_info.merge(corr_table[corr_table.product_id.isin(self.rewards_info.product_id)]))

    def collect_members_features(self):

        print('Collecting features for members...')
        self.members = read_sql(f'''select memberid, channel from marketing.cvm.{self.table_members}''')
        for f in ['campaign_name', 'start_date', 'promo_type', 'n_days_promo', 'frequency_level', 'promo_weekdays']:
            self.members[f] = self.cmp_config.get(f)

        self.cmp_config.update({
            'columns_from_pfile': self.features_config.get('columns_from_pfile')
        })

        pipe = ProceduresPipeline(**self.cmp_config)
        print('Collecting info on\n')
        for name, sql_query in pipe.get_procedures_for_members_features():
            sys.stdout.write(f'\n{name}')
            start_time = time.time()
            cursor.execute(sql_query)
            sys.stdout.write(f' - {time.time() - start_time:.2f}s')

    def preprocess_data(self, raw_data):
        final_data = preprocess_historic_columns(raw_data)
        final_data = preprocess_campaign_features(final_data, self.label_encoders)
        return final_data

    def predict_scores(self, data, product_id):
        model_features = self.features_config.get('features_for_model')
        cg_columns = self.features_config.get('cg_columns')

        model_pg = pk.load(open(self.cmp_config.get('model_pg_path'), "rb"))
        model_cg = pk.load(open(self.cmp_config.get('model_cg_path'), "rb"))

        X = data[model_features]
        X_cg = X.copy()
        X_cg[cg_columns] = 0

        print('\nPredicting uplift scores')
        preds_mpg = model_pg.predict_proba(X)
        preds_mcg = model_cg.predict_proba(X_cg)
        preds = preds_mpg - preds_mcg

        data['model_pg_score'] = preds_mpg[:, 1]
        data['model_cg_score'] = preds_mcg[:, 1]
        data['uplift_score'] = preds[:, 1]

        self.results = data.sort_values('uplift_score')

        path_to_save = self.cmp_config.get('path_to_save_results')

        file_name = f'{path_to_save}/uplift_scores_for_{self.campaign_name}_{product_id}.csv'
        self.results[['memberid', 'product_id', 'model_pg_score', 'model_cg_score', 'uplift_score']].to_csv(file_name,
                                                                                                            index=False)
        print(f'Results are saved in {file_name}')
        plt.figure()
        plt.title(f'Uplift score for {product_id}')
        plt.plot(range(0, len(self.results)), self.results.uplift_score)
        plt.axhline(color='black', linewidth=.5)
        plt.show()

    def run(self):

        self.collect_members_features()
        pca_members = pk.load(open(self.cmp_config.get('pca_members_path'), "rb"))
        pca_items = pk.load(open(self.cmp_config.get('pca_items_path'), "rb"))
        mbr_df, members_nbo = nbo_members(self.members, self.table_members, pca_members)

        for row in tqdm(list(self.rewards_info.iterrows())):
            print(f'Iteration {row[0]}')
            product_id = row[1]['product_id']
            reward_name = row[1]['reward_name']
            rewardvalue = row[1]['rewardValue']
            print(product_id, reward_name, rewardvalue)

            self.cmp_config.update({
                'product_id': product_id,
                'reward_name': reward_name,
                'rewardvalue': rewardvalue
            })

            similarity, euc_dist, pf_20 = nbo_product(product_id, pca_items, members_nbo)

            to_date = get_start_thursday_before_n_weeks(self.start_date, 1)
            from_date = get_start_thursday_before_n_weeks(to_date, 12)
            prod_price = get_productid_price_features(product_id, from_date, to_date)

            campaign = merge_local_features(mbr_df, pf_20, prod_price, similarity, euc_dist)
            for f in ['reward_name', 'rewardvalue', 'product_id']:
                campaign[f] = self.cmp_config.get(f)

            pipe = ProceduresPipeline(**self.cmp_config)
            print('\nStart running procedures...\n Collecting info on\n')
            for name, sql_query in pipe.get_procedures_for_prod_features():
                sys.stdout.write(f'\n{name}')
                start_time = time.time()
                cursor.execute(sql_query)
                sys.stdout.write(f' - {time.time() - start_time:.2f}s')

            final_merge_pipe = Procedures(**self.cmp_config)
            sys.stdout.write('\nAll data_prep is collected. Final  merge...')
            sql_query = final_merge_pipe.sp_final_merge_with_agg()
            start_time = time.time()
            cursor.execute(sql_query)
            sys.stdout.write(f' - {time.time() - start_time:.2f}s')

            # collect data_prep locally
            table_final = final_merge + self.campaign_name
            exec_features = read_sql(f'select * from {table_final}')
            final_raw_data = campaign.merge(exec_features)

            # get slope dynamics
            trn_df = get_total_ntrn_history(self.start_date)
            trn_slope_dict = get_slope_by_time(trn_df, name_suffix='w_total')

            for f in trn_slope_dict.keys():
                final_raw_data[f] = trn_slope_dict[f]

            prod_df = get_m4_ntrn_history(product_id, self.start_date, m_level='m4')
            prod_slope_dict = get_slope_by_time(prod_df, name_suffix='w_m4_loyal')

            for f in prod_slope_dict.keys():
                final_raw_data[f] = prod_slope_dict[f]

            final_raw_data.columns = [col.lower() for col in final_raw_data.columns]
            self.data = final_raw_data
            # data_prep preprocessing
            sys.stdout.write('\nStart data_prep preprocessing')
            start_time = time.time()
            final_data = self.preprocess_data(final_raw_data)
            sys.stdout.write(f' - {time.time() - start_time:.2f}s')

            # model fitting
            self.predict_scores(final_data, product_id)





