import pickle as pk
import pandas as pd
from utils.tools import load_yaml, get_start_thursday_before_n_weeks
from utils.db_conn import connect_to_db, read_sql
from data_prep.procedures import ProceduresPipeline
from data_prep.local_features import nbo_members, nbo_product, get_productid_price_features, merge_local_features
from data_prep.preprocessing import preprocess_historic_columns, preprocess_campaign_features
from data_prep.trend_features import get_slope_by_time, get_total_ntrn_history, get_m4_ntrn_history
import time
import sys
import os

db_config = connect_to_db()
cursor = db_config['cursor']
db_conn = db_config['conn']

# TODO: change
final_merge = 'Marketing.cvm.frq_uplift_features_campaign_'


class SingleCmpDesign:

    def __init__(self, cmp_config_path):
        self.cmp_config = load_yaml(cmp_config_path)
        self.campaign_name = self.cmp_config.get('campaign_name')
        self.features_config = load_yaml(self.cmp_config.get('features_config'))
        self.label_encoders = pk.load(open(self.cmp_config.get('label_encoders_path'), "rb"))
        self.final_raw_data = None
        self.final_data = None

    def load_data(self):
        table_members = self.cmp_config.get('new_table_members')
        product_id = self.cmp_config.get('product_id')
        start_date = pd.to_datetime(self.cmp_config.get('start_date'))

        pca_members = pk.load(open(self.cmp_config.get('pca_members_path'), "rb"))
        pca_items = pk.load(open(self.cmp_config.get('pca_items_path'), "rb"))

        # get members
        sys.stdout.write('Start importing members')
        start_time = time.time()
        members = read_sql(f'''select memberid, channel from marketing.cvm.{table_members}''')
        sys.stdout.write(f' - {time.time() - start_time:.2f}s\n')

        for f in [
            'campaign_name', 'start_date', 'product_id', 'reward_name', 'rewardvalue',
            'promo_type', 'n_days_promo', 'frequency_level', 'promo_weekdays'
        ]:
            members[f] = self.cmp_config.get(f)

        # LOCAL DATA (PCA)
        sys.stdout.write('Start loading embeddings')
        start_time = time.time()
        mbr_df, members_nbo = nbo_members(members, table_members, pca_members)
        similarity, euc_dist, pf_20 = nbo_product(product_id, pca_items, members_nbo)

        to_date = get_start_thursday_before_n_weeks(start_date, 1)
        from_date = get_start_thursday_before_n_weeks(to_date, 12)
        prod_price = get_productid_price_features(product_id, from_date, to_date)

        # merge local features
        campaign = merge_local_features(mbr_df, pf_20, prod_price, similarity, euc_dist)
        sys.stdout.write(f' - {time.time() - start_time:.2f}s\n')

        # SQL PROCEDURES
        procedures_config = self.cmp_config
        procedures_config.update({
            'start_date': start_date,
            'columns_from_pfile': self.features_config.get('columns_from_pfile')
        })

        pipe = ProceduresPipeline(**procedures_config)
        print('Start running procedures. Collecting info on...\n')
        for name, sql_query in pipe.get_procedures_for_single_cmp_design():
            sys.stdout.write(f'\n\t{name}')
            start_time = time.time()
            cursor.execute(sql_query)
            sys.stdout.write(f' - {time.time() - start_time:.2f}s')

        # merge data_prep
        final_table = final_merge + f'{self.campaign_name}'
        exec_features = read_sql(f'select * from {final_table}')
        self.final_raw_data = campaign.merge(exec_features)

        # get slope dynamics
        trn_df = get_total_ntrn_history(start_date)
        trn_slope_dict = get_slope_by_time(trn_df, name_suffix='w_total')

        for f in trn_slope_dict.keys():
            self.final_raw_data[f] = trn_slope_dict[f]

        prod_df = get_m4_ntrn_history(product_id, start_date, m_level='m4')
        prod_slope_dict = get_slope_by_time(prod_df, name_suffix='w_m4_loyal')

        for f in prod_slope_dict.keys():
            self.final_raw_data[f] = prod_slope_dict[f]

        self.final_raw_data.columns = [col.lower() for col in self.final_raw_data.columns]
        # TODO: datatypes

    def preprocess_data(self):
        sys.stdout.write('Start data_prep preprocessing')
        start_time = time.time()
        self.final_data = preprocess_historic_columns(self.final_raw_data)
        self.final_data = preprocess_campaign_features(self.final_data, self.label_encoders)
        sys.stdout.write(f' - {time.time() - start_time:.2f}s')

    def get_scores(self):
        # model params
        model_features = self.features_config.get('features_for_model')
        cg_columns = self.features_config.get('cg_columns')

        model_pg = pk.load(open(self.cmp_config.get('model_pg_path'), "rb"))
        model_cg = pk.load(open(self.cmp_config.get('model_cg_path'), "rb"))

        X = self.final_data[model_features]
        X_cg = X.copy()
        X_cg[cg_columns] = 0
        print('Predicting uplift scores')
        preds_mpg = model_pg.predict_proba(X)
        preds_mcg = model_cg.predict_proba(X_cg)
        preds = preds_mpg - preds_mcg

        self.final_data['model_pg_score'] = preds_mpg[:, 1]
        self.final_data['model_cg_score'] = preds_mcg[:, 1]
        self.final_data['uplift_score'] = preds[:, 1]

        results = self.final_data.sort_values('uplift_score')

        product_id = self.cmp_config.get('product_id')
        path_to_save = self.cmp_config.get('path_to_save_results')

        if not os.path.exists(path_to_save):
            os.mkdir(path_to_save)

        file_name = f'{path_to_save}/uplift_scores_for_{self.campaign_name}_{product_id}.csv'
        results.to_csv(file_name, index=False)
        print(f'Results are saved in {file_name}')
