from utils.db_conn import connect_to_db
from utils.tools import get_start_thursday_before_n_weeks
import pandas as pd
import datetime as dt
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression

db_conn = connect_to_db()['conn']
db_cursor = connect_to_db()['cursor']


def get_total_ntrn_history(end_date: pd.Timestamp, n_weeks: int = 24) -> pd.DataFrame:

    min_th = get_start_thursday_before_n_weeks(end_date, n_weeks)
    closest_th = get_start_thursday_before_n_weeks(end_date, 1)
    max_th_available = pd.to_datetime(
        str(
            pd.read_sql(
                ''' select max(weekstart_th) from Marketing.cvm.frq_trn_history ''',
                db_conn).values[0, 0]))

    if closest_th > max_th_available:

        print(f'No data is found since {str(max_th_available)}.'
              ' Updating table Marketing.cvm.frq_trn_history...')

        p = f'''
            exec Marketing.cvm.frq_weekly_total_trn_silpo
                @start_date = '{str(max_th_available + dt.timedelta(days=7))}',
                @end_date = '{str(closest_th)}'
        '''
        db_cursor.execute(p)

    q = f'''
        select 
            weekstart_th
            ,sum(total_ntrn) as n_trn
        from Marketing.cvm.frq_trn_history
        where weekstart_th between '{str(min_th.date())}' and '{str(closest_th.date())}'
        group by weekstart_th
    '''
    data = pd.read_sql(q, db_conn)

    return data.sort_values(by='weekstart_th')


def get_m4_ntrn_history(product_id: int, end_date: pd.Timestamp, m_level: str = 'm4', n_weeks: int = 24) -> pd.DataFrame:

    min_th = get_start_thursday_before_n_weeks(end_date, n_weeks)
    max_th = get_start_thursday_before_n_weeks(end_date, 1)

    q = f'''
        with lagers as (
            select id
            from marketing..new_macro_data_for_program 
            where {m_level} in (select distinct {m_level} from Marketing.cvm.ListM4BrandId where id = {product_id})) 
        select 
            weekstart_th
            ,sum(ntrn) as n_trn
        from marketing.cvm.weekly_lager_stats
        where weekstart_th between '{str(min_th.date())}' and '{str(max_th.date())}'
            and lagerid in (select id from lagers)
        group by weekstart_th
            '''

    data = pd.read_sql(q, db_conn)

    return data.sort_values(by='weekstart_th')


def get_slope_by_time(data,
                      name_suffix='',
                      value_col='n_trn',
                      date_col='weekstart_th',
                      n_last_periods=[24, 12, 4]) -> dict:

    data['date_ordinal'] = pd.to_datetime(data[date_col]).map(dt.datetime.toordinal)

    result = {}

    for n in n_last_periods:
        X = data['date_ordinal'][-n:].values.reshape(-1, 1)
        y = data[value_col][-n:].values.reshape(-1, 1)

        sc = StandardScaler()
        y_t = sc.fit_transform(y)

        reg = LinearRegression()
        reg.fit(X, y_t)

        result[f'{value_col}_slope_{n}{name_suffix}'] = reg.coef_[0][0]

    return result
