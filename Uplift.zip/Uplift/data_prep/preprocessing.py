import pandas as pd
import numpy as np


fill0 = ['agg_kolvo_m2_2_w',
        'agg_rev_m2_2_w',
        'agg_kolvo_m3_2_w',
        'agg_rev_m3_2_w',
        'agg_kolvo_m4_2_w',
        'agg_rev_m4_2_w',
        'agg_kolvo_pr_2_w',
        'agg_rev_pr_2_w',
        'agg_kolvo_m2_3_months',
        'agg_rev_m2_3_months',
        'agg_kolvo_m3_3_months',
        'agg_rev_m3_3_months',
        'agg_kolvo_m4_3_months',
        'agg_rev_m4_3_months',
        'agg_kolvo_pr_3_months',
        'agg_rev_pr_3_months',
        'sum_cheque_lag3',
        'n_diff_lagers_lag3',
        'ntrn_a',
        'purchase_character',
        'ntrn_r2',
        'ntrn_slope',
        'sum_cheque_lag2',
        'n_diff_lagers_lag2',
        'sum_cheque_lag1',
        'n_diff_lagers_lag1',
        'n_days_with_transactions',
        'rewardvalue',
        'silpo_loyalty',
        'brand_loyalty']

fill90 = ['last_visit_days_ago', 'ndays_diff_lag3', 'ndays_diff_lag2',
              'ndays_diff_lag1', 'ndays_diff_min', 'ndays_diff_max',
              'ndays_diff_mean']

col_cat = ['gender']

mean_fill = ['lifetime', 'days_for_repurchase_avg',
                 'ftg_count', 'main_weekdays_count',
                 'ftg_weekdays_count', 'ftg_weekend_count',
                 'buys_count', 'side_weekend_count', 'avg_cheque',
                 'side_count', 'main_count', 'main_weekend_count',
                 'side_weekdays_count']

mean_fill_round = ['lifestyle13', 'lifestyle7', 'lyfistage', 'age']


def preprocess_historic_columns(df):
    # TODO: change to_numeric after adding datatypes

    # df.drop(columns=['promo_weekdays', 'maritalstatus'], axis=1, inplace=True)

    df['visit_delta'].fillna(value=30, inplace=True)
    df['ndays_diff_std'].fillna(value=100, inplace=True)
    df['price_sencetivity'].fillna(value=4, inplace=True)
    df['priceclusterid'].fillna(value=13, inplace=True)
    df['days_from_last_purchase'].fillna(value=100, inplace=True)

    for col in fill0:
        df[col] = pd.to_numeric(df[col].fillna(0))

    for col in fill90:
        df[col] = pd.to_numeric(df[col].fillna(90))

    for col in col_cat:
        df[col] = df[col].fillna(df[col].value_counts().index[0])

    for col in mean_fill:
        df[col] = pd.to_numeric(df[col].fillna(df[col].mean()))

    for col in mean_fill_round:
        df[col] = pd.to_numeric(df[col].fillna(np.round(df[col].mean(), 0)))

    df['m4_m3_2w'] = np.where(df['agg_kolvo_m3_2_w'] != 0,
                              df['agg_kolvo_m4_2_w'] / df['agg_kolvo_m3_2_w'], 0)
    df['m3_m2_2w'] = np.where(df['agg_kolvo_m3_2_w'] != 0,
                              df['agg_kolvo_m4_2_w'] / df['agg_kolvo_m3_2_w'], 0)

    df['m4_m3_3m'] = np.where(df['agg_kolvo_m2_3_months'] != 0,
                              df['agg_kolvo_m3_3_months'] / df['agg_kolvo_m2_3_months'], 0)
    df['m3_m2_3m'] = np.where(df['agg_kolvo_m2_3_months'] != 0,
                              df['agg_kolvo_m3_3_months'] / df['agg_kolvo_m2_3_months'], 0)

    df['days_from_last_purchase_diff'] = df['days_from_last_purchase'].mean() - df['days_from_last_purchase']
    df['cycles_diff'] = df['number_cycles_from_last_purchase'].mean() - df['number_cycles_from_last_purchase']

    df['cheque_lag_2_1'] = np.where(df['sum_cheque_lag2'] != 0,
                                    df['sum_cheque_lag2'] - df['sum_cheque_lag1'], 0)
    df['cheque_lag_3_2'] = np.where(df['sum_cheque_lag3'] != 0,
                                    df['sum_cheque_lag3'] - df['sum_cheque_lag2'], 0)
    df['cheque_lag_total'] = df['cheque_lag_3_2'] + df['cheque_lag_2_1']

    df['n_diff_lagers_lag_3_2'] = np.where(df['n_diff_lagers_lag3'] != 0,
                                           df['n_diff_lagers_lag3'] - df['n_diff_lagers_lag2'], 0)
    df['n_diff_lagers_lag_2_1'] = np.where(df['n_diff_lagers_lag2'] != 0,
                                           df['n_diff_lagers_lag2'] - df['n_diff_lagers_lag1'], 0)
    df['n_diff_total'] = df['n_diff_lagers_lag_2_1'] + df['n_diff_lagers_lag_3_2']

    df['weight_in_bucket'] = np.where(df['avg_cheque'] != 0,
                                      (df['price_pr'] * df['agg_kolvo_pr_3_months'] / 3) / df['avg_cheque'], 0)
    df['abs_discount'] = np.where(df['rewardvalue'] != 0,
                                  df['price_pr'] * (df['rewardvalue'] * 0.01), 0)
    df['weight_of_discount'] = np.where(df['avg_cheque'] != 0,
                                        df['abs_discount'] / df['avg_cheque'], 0)
    df['average_weight_in_bucket'] = np.where(df['avg_cheque'] != 0,
                                              df['abs_discount'] / df['avg_cheque'], 0)

    return df


def preprocess_campaign_features(df, label_encoders):
    df = df.copy()

    le_channel = label_encoders['channel']
    le_rn = label_encoders['reward_name']
    le_pt = label_encoders['promo_type']

    # encoding of campaign variables
    df['promo_type'] = le_pt.transform(df.promo_type)
    df['channel'] = le_channel.transform(df.channel)

    # reward columns
    df[['reward_name', 'rewardvalue']] = df[['reward_name', 'rewardvalue']].fillna(value=0)
    df['reward_name'] = df['reward_name'].apply(lambda x: str(x))
    df['rewardvalue'] = pd.to_numeric(df['rewardvalue'])

    df['reward_name'] = le_rn.transform(df.reward_name)

    # filling missing variables
    df.fillna(0, inplace=True)

    return df
