from scipy import spatial
import pickle as pk
from utils.db_conn import read_sql, connect_to_db
import numpy as np
import pandas as pd

db_conn = connect_to_db()['conn']


def nbo_members(members, table_members: str, pca_members: pk):
    members_nbo = read_sql(f'''
        select mbrs.memberID as memberid_original, 
        uf.* from Marketing.cvm.{table_members} mbrs 
        left join Marketing.cvm.model_als_m4brandid_all_members_1002_user_factors uf
        on uf.memberid = mbrs.memberId''')

    members_nbo = members_nbo[members_nbo.memberid.isin(members.memberid)]
    members_nbo.drop('memberid', axis=1, inplace=True)
    members_nbo_av = np.array(members_nbo.dropna().set_index('memberid_original').mean())
    members_with_no_nbo = np.array(members[~members.memberid.isin(members_nbo.memberid_original)].memberid)
    additional_members = pd.DataFrame(np.array([list(members_nbo_av)] *
                                               len(members_with_no_nbo)))
    additional_members['memberid'] = members_with_no_nbo
    if len(members_with_no_nbo) == 0:
        for i in range(150):
            additional_members[i] = 0

    additional_members = additional_members[['memberid'] + [i for i in range(150)]]
    additional_members.columns = members_nbo.columns
    members_nbo['is_nbo'] = 1
    additional_members['is_nbo'] = 0
    members_nbo = pd.concat(
        [members_nbo[~members_nbo['memberid_original'].isin(members_with_no_nbo)], additional_members])
    is_nbo = members_nbo[['memberid_original', 'is_nbo']]
    members_nbo.drop('is_nbo', axis=1, inplace=True)
    members_nbo.columns = ['memberid'] + [i for i in range(150)]

    uf_20 = pd.DataFrame(pca_members.transform(members_nbo.set_index('memberid'))).add_prefix('member_')
    uf_20['memberid'] = np.array(members_nbo.memberid)

    is_nbo.columns = ['memberid', 'is_nbo']
    members_nbo = members_nbo.set_index('memberid')
    mbr_df = members.merge(is_nbo).merge(uf_20)

    return mbr_df, members_nbo


def nbo_product(product_id, pca_items, members_nbo):
    try:
        product_nbo = read_sql(f'''
            select pf.* 
            from Marketing.cvm.model_als_m4brandid_all_members_1002_item_factors as pf
            where productid = {product_id}''')
    except:
        product_nbo = read_sql('''select pf.*
                        from Marketing.cvm.model_als_m4brandid_all_members_1002_item_factors as pf''')
        product_nbo = pd.DataFrame(product_nbo.set_index('productid').mean()).T
        product_nbo['productid'] = product_id

    pf_20 = pd.DataFrame(pca_items.transform(product_nbo.set_index('productid'))).add_prefix('item_')
    pf_20['productid'] = product_id

    product_nbo = product_nbo.set_index('productid')

    # distances calculation
    s_temp = []
    euc_temp = []
    for i in range(len(members_nbo)):
        s_temp.append(1 - spatial.distance.cosine(members_nbo.iloc[i, :], product_nbo.iloc[0, :]))
        euc_temp.append(np.linalg.norm(np.array(members_nbo.iloc[i, :]) - np.array(product_nbo.iloc[0, :])))

    similarity = pd.DataFrame(s_temp, columns=['similarity'])
    euc_dist = pd.DataFrame(euc_temp, columns=['euc_dist'])
    similarity['memberid'] = members_nbo.reset_index().memberid
    euc_dist['memberid'] = members_nbo.reset_index().memberid

    return similarity, euc_dist, pf_20


def get_productid_price_features(product_id, from_date, to_date):
    query = f"""
        with pr as (
            select 
                nmp.id as lagerid,
                lmb.id as productid,
                nmp.m4
            from Marketing.dbo.new_macro_data_for_program nmp (nolock)
               left join Marketing.cvm.ListM4BrandId as lmb (nolock)
                   on (lmb.m4=nmp.m4 or (lmb.m4 is null and nmp.m4 is null))
                   and (lmb.brandId=nmp.BrandID or (lmb.brandId is null and nmp.BrandID is null))
            where lmb.id = {product_id}
        )
        select  
            ls.lagerid,
            productid,
            m4,
            sum(kolvo) kolvo,
            sum(rev) rev,
            sum(ntrn) ntrn,
            sum(fm) fm,
            sum(mems) mems
        from Marketing.cvm.weekly_lager_stats ls (nolock)
            join pr
                on ls.lagerid = pr.lagerid
        where weekstart_th between '{str(from_date)}' and '{str(to_date)}'
        group by ls.lagerid, productid, m4
    """
    lager_stats = pd.read_sql(query, db_conn)

    lager_stats['price_pr'] = lager_stats['rev'] / lager_stats['kolvo']

    productId_stats = lager_stats.groupby(['productid'])[['price_pr']].median().reset_index()
    m4_stats = lager_stats.groupby('m4')[['price_pr']].median().reset_index()
    m4_stats.columns = ['m4', 'price_m4']

    prices = lager_stats[['productid', 'm4']].drop_duplicates().merge(
        m4_stats, how='left').merge(productId_stats,
                                    how='left')
    prices['ratio_pr_m4'] = prices['price_pr'] / prices['price_m4']
    prices.dropna(inplace=True)

    return prices


def merge_local_features(mbr_df, pf_20, prod_price, similarity, euc_dist):
    prod_price = prod_price[['productid', 'price_m4', 'price_pr', 'ratio_pr_m4']].copy()
    prod_df = prod_price.merge(pf_20)
    mbr_df = mbr_df.merge(similarity).merge(euc_dist)
    campaign = mbr_df.assign(key=1).merge(prod_df.assign(key=1), on='key').drop('key', axis=1)

    return campaign
