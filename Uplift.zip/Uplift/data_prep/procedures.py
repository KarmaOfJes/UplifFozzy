from utils.db_conn import read_sql, connect_to_db
import numpy as np
import pandas as pd
from dateutil.relativedelta import relativedelta

from utils.tools import get_start_thursday_before_n_weeks

db_config = connect_to_db()
cursor = db_config['cursor']
db_conn = db_config['conn']


class Procedures:

    def __init__(self, **config):
        # general
        self.start_date = pd.to_datetime(config.get('start_date'))
        self.new_table_members = config.get('new_table_members')
        self.product_id = config.get('product_id')
        self.new_table_pfile = config.get('new_table_pfile')
        self.new_table_last_visits = config.get('new_table_last_visits')
        self.new_table_3m_prod_sales = config.get('new_table_3m_prod_sales')
        self.new_table_2w_prod_sales = config.get('new_table_2w_prod_sales')
        self.table_historic_trn = config.get('table_historic_trn')
        self.new_table_agg_trn_data = config.get('new_table_agg_trn_data')
        self.table_historic_trn = config.get('table_historic_trn')
        self.new_table_last_3trn = config.get('new_table_last_3trn')
        self.new_table_repurchase_cycle = config.get('new_table_repurchase_cycle')
        self.table_with_aggregates = config.get('table_with_aggregates')
        # profile features config
        self.columns_from_pfile = config.get('columns_from_pfile')

        # self.campaign_name_for_table_name = config.get('self.campaign_name_for_table_name')
        # for train only
        self.campaign_name = config.get('campaign_name')
        self.final_block_1 = config.get('final_block_1')

    def sp_pfile_features(self):
        # Collect features for members from profile

        sql = f'''
            exec Marketing.cvm.sp_PfileFeaturesMembersFrqCampaign
                @start_date = '{str(self.start_date)[:10]}',
                @table_with_members = '{self.new_table_members}',
                @newTableName = '{self.new_table_pfile}',
                @columns_to_take = '{', '.join(self.columns_from_pfile)}'
        '''
        return sql

    def sp_last_visits(self):
        # Get data_prep on the last visit for the previous month till start_date

        sql = f'''
            exec Marketing.cvm.sp_LastVisitUplift
                @start_date = '{str(self.start_date)[:10]}',
                @prev_month = '{str(self.start_date + relativedelta(months=-1))[:10]}',
                @table_with_members = '{self.new_table_members}',
                @newTableName = '{self.new_table_last_visits}'
        '''
        return sql

    def sp_product_historic_sales_3m(self):
        # Collect data_prep on specific product sales for every member for last 3 months

        three_weeks_before = get_start_thursday_before_n_weeks(self.start_date, 3)
        week_before = get_start_thursday_before_n_weeks(self.start_date, 1)
        three_months_before = get_start_thursday_before_n_weeks(self.start_date, 12)

        sql = f'''
                exec Marketing.cvm.sp_ThreeMonthsHistory
                    @start_date  = '{str(self.start_date)[:10]}',
                    @table_with_members  = '{self.new_table_members}',
                    @newTableName  = '{self.new_table_3m_prod_sales}',
                    @three_weeks_before = '{str(three_weeks_before)[:10]}',
                    @week_before   = '{str(week_before)[:10]}',
                    @three_months  = '{str(three_months_before)[:10]}',
                    @product_id  = '{str(self.product_id)}'
            '''
        return sql

    def sp_product_historic_sales_2w(self):
        # Collect data_prep on specific product sales for every member for last 2 weeks

        three_weeks_before = get_start_thursday_before_n_weeks(self.start_date, 3)
        week_before = get_start_thursday_before_n_weeks(self.start_date, 1)
        three_months_before = get_start_thursday_before_n_weeks(self.start_date, 12)

        sql = f'''
                exec Marketing.cvm.sp_TwoWeeksHistory
                    @start_date  = '{str(self.start_date)[:10]}',
                    @table_with_members = '{self.new_table_members}',
                    @newTableName  = '{self.new_table_2w_prod_sales}',
                    @three_weeks_before  = '{str(three_weeks_before)[:10]}',
                    @week_before   = '{str(week_before)[:10]}',
                    @three_months  = '{str(three_months_before)[:10]}',
                    @product_id  = '{self.product_id}'
            '''
        return sql

    def sp_historic_trn_agg(self):
        # Collect aggregates for historic transactions for the last 3 months
        # TODO: separate collection of full trn and its aggregates

        three_months_before = get_start_thursday_before_n_weeks(self.start_date, 12)

        sql = f'''
                exec Marketing.cvm.sp_HistoricTransactionsUplift
                    @start_date = '{str(self.start_date)[:10]}',
                    @three_months_before = '{str(three_months_before)[:10]}',
                    @table_with_members = '{self.new_table_members}',
                    @table_with_history = '{self.table_historic_trn}',
                    @newTableName = '{self.new_table_agg_trn_data}'
            '''
        return sql

    def sp_historic_last3trn(self):
        # Collect data_prep on the last 3 transactions for the previous 3 months

        three_months_before = get_start_thursday_before_n_weeks(self.start_date, 12)

        sql = f'''
                exec Marketing.cvm.sp_ThreeTransactionsUplift
                    @start_date = '{str(self.start_date)[:10]}',
                    @three_months_before = '{str(three_months_before)[:10]}',
                    @table_with_members = '{self.new_table_members}',
                    @table_with_history = '{self.table_historic_trn}',
                    @newTableName = '{self.new_table_last_3trn}'
            '''
        return sql

    def sp_repurchase_cycle(self):
        q = f'''with correspondence_table as (
                    select nmp.id as lagerid, lmb.id as product_id, nmp.name4, nmp.m3
                    from Marketing.cvm.new_macro_data_for_program_copy nmp
                    left join Marketing.cvm.ListM4BrandId as lmb
                    on (lmb.m4=nmp.m4 or (lmb.m4 is null and nmp.m4 is null))
                    and (lmb.brandId=nmp.BrandID or (lmb.brandId is null and nmp.BrandID is null)))
                select distinct m3 from correspondence_table where product_id = {self.product_id} '''
        m3 = read_sql(q)
        m3 = np.array(m3)[0][0]

        three_months_before = self.start_date + relativedelta(months=-3)

        sql = f'''
                exec Marketing.cvm.sp_UpliftRepurchaseCycle
                    @start_date = '{str(self.start_date)[:10]}',
                    @date_left = '{str(three_months_before)[:10]}',
                    @m3 = {m3},
                    @table_with_members = '{self.new_table_members}',
                    @newTableName = '{self.new_table_repurchase_cycle}'
            '''
        return sql

    def sp_final_merge_with_agg(self):
        sql = f'''
            exec Marketing.cvm.sp_UpliftFeaturesFinalMerge_new 
                @campaign_name = '{self.campaign_name}', 
                @table_with_members = '{self.new_table_members}',
                @table_with_pfile = '{self.new_table_pfile}',
                @table_with_last_visit = '{self.new_table_last_visits}',
                @table_with_three_months = '{self.new_table_3m_prod_sales}',
                @table_with_two_weeks = '{self.new_table_2w_prod_sales}',
                @columns_to_take_from_pfile = '{', '.join(['pfile.' + i for i in self.columns_from_pfile[1:]])}',
                @table_with_repurch_cycle = {self.new_table_repurchase_cycle},
                @table_with_hist_cheques = {self.new_table_agg_trn_data},
                @table_with_hist_3cheques = {self.new_table_last_3trn}
                ,@table_with_aggregates = {self.table_with_aggregates}
        '''
        return sql

    def sp_train_find_members(self):
        # Collect members from finished campaigns for model train

        sql = f'''
            exec Marketing.cvm.sp_UpliftTrainMembers
                @campaign_name = '{self.campaign_name}', 
                @newTableName = '{self.new_table_members}'
        '''
        return sql

    def sp_train_merge_block_1(self):
        # Insert historical sales features into one table

        sql = f'''
            exec Marketing.cvm.sp_UpliftFeaturesInsertTrain
                @campaign_name = '{self.campaign_name}',
                @table_with_members = '{self.new_table_members}',
                @table_with_last_visit = '{self.new_table_last_visits}',
                @table_with_three_months = '{self.new_table_3m_prod_sales}',
                @table_with_two_weeks = '{self.new_table_2w_prod_sales}',
                @newTableName = '{self.final_block_1}'
            '''
        return sql


class ProceduresPipeline(Procedures):
    def __init__(self, **config):
        super().__init__(**config)

    def get_procedures_for_single_cmp_design(self):
        pipeline = [
            ('features from members profile', super().sp_pfile_features()),
            ('last visits', super().sp_last_visits()),
            ('historical product sales for 3 months', super().sp_product_historic_sales_3m()),
            ('historical product sales for 2 weeks', super().sp_product_historic_sales_2w()),
            ('historical transaction aggregates', super().sp_historic_trn_agg()),
            ('last three transactions', super().sp_historic_last3trn()),
            ('repurchase cycle', super().sp_repurchase_cycle()),
            (f'All data is collected. Final  merge...', super().sp_final_merge_with_agg())
        ]

        return pipeline

    def get_procedures_for_members_features(self):
        pipeline = [
            ('features from members profile', super().sp_pfile_features()),
            ('last visits', super().sp_last_visits()),
            ('historical transaction aggregates', super().sp_historic_trn_agg()),
            ('last three transactions', super().sp_historic_last3trn())
        ]

        return pipeline

    def get_procedures_for_prod_features(self):
        pipeline = [
            ('historical product sales for 3 months', super().sp_product_historic_sales_3m()),
            ('historical product sales for 2 weeks', super().sp_product_historic_sales_2w()),
            ('repurchase cycle', super().sp_repurchase_cycle())
        ]

        return pipeline
